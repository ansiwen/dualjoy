%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-11T12:29:30+02:00*%
%TF.ProjectId,dualjoy-top-plate,6475616c-6a6f-4792-9d74-6f702d706c61,1.0*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-11 12:29:30*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H1*%
X117269900Y-82667600D03*
%TD*%
%TO.C,H4*%
X173709900Y-128657600D03*
%TD*%
%TO.C,H2*%
X173709900Y-82667600D03*
%TD*%
%TO.C,H3*%
X117269900Y-128657600D03*
%TD*%
M02*
